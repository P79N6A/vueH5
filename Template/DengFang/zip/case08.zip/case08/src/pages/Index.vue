<template>
  <section id="template">
    <div class="loading" v-if="inLoading || inReady">
      <img src="../assets/loading-bars.svg">
    </div>
    <!--音乐播放/暂停按钮-->
    <div class="music-image" :class='inPlay?"music-active":""' :style='{backgroundImage:"url("+images.music_image+")"}'
         @click="playMusic"></div>
    <!--音乐播放器-->
    <audio loop="loop" id="audio" :src="music"></audio>
    <!--锦囊按钮-->
    <div class="silk-bag-icon" :style='{backgroundImage:"url("+images.silk_bag_image+")"}'
         @click="showSilkBag"></div>
    <!--模板私有内容 -->
    <div class="bargain">
      <List v-if="show === 'list'" @toBargain="toBargain"></List>
      <Bargain v-if="show === 'bargain'" @tryAgain="tryAgain"></Bargain>
      <FriendBargain v-if="show === 'friendBargain'" @friendTty="friendTty"></FriendBargain>
    </div>
    <!--锦囊组件-->
    <SilkBag v-if="hasShowSilkBag" v-on:child-say="hideSilkBag"></SilkBag>
    <Loading v-if="loading"></Loading>
  </section>
</template>
<script>
  //引入锦囊组件
  import SilkBag from "../components/SilkBag.vue";
  import Loading from '../components/Loading.vue';
  import List from '../components/Home.vue';
  import Bargain from '../components/Bargain.vue';
  import FriendBargain  from '../components/FriendBargain.vue';
  import {authorize} from '../services/authorize';
  //引入json文件
  import{getConfig} from '../services/getConfig';
  import{getDetails} from '../services/getDetails';
  //获取微信签名注册
  import{getWXConfig} from '../services/getWXConfig';
  export default {
    //注册引入的组件
    components: {
      SilkBag,
      Loading,
      List,
      Bargain,
      FriendBargain
    },
    data() {
      return {
        // ---------------------共用属性-----------------------
        xjjOpenId: '',
        openId: '',
        activityId: '',
        defaultFrom: '',
        storeCode: '',
        //---------------模板链接数据 end-------------
        config: {},
        loading: false,
        inLoading: true, //加载状态
        inReady: true,
        images: {}, //图片集--用作图片展示
        imageArr: [],//图片集--用作判断图片加载状态
        iCur: 0, //图片加载的序号
        music: '', //音乐地址
        inPlay: false, //是否在播放音乐
        hasShowSilkBag: false, //是否展示锦囊
        // ---------------------私有属性-----------------------
        hasBargain: false, //是否确认砍价对象
        details: {}, //砍价对象详情
        //-------------------------
        show: '',
        shareImage: {},
        wxConfig: {},
        shareId: -1,
        bargainList: [],
        bargain: {}
      }
    },
    created(){      //生命钩子 -- 组件实例创建完成，属性已绑定，还为生成DOM
      document.querySelector("body").addEventListener("touchmove", function (e) {
        e.preventDefault();
      });

      this.checkedRouter();
    },
    watch: {
      '$route': 'checkedRouter',
      'show': 'setWXConfig'
    },
    methods: {
      checkedRouter(){
        //获取路由上的参数
        this.friendOpenId = this.getVal('friendOpenId') ? this.getVal('friendOpenId') : this.$route.query.friendOpenId;
        this.openId = this.getVal('openId') ? this.getVal('openId') : this.$route.query.openid;
        this.activityId = this.getVal('activity_id') ? this.getVal('activity_id') : this.$route.query.activity_id;
        this.defaultFrom = this.getVal('defaultFrom') ? this.getVal('defaultFrom') : this.$route.query.defaultFrom;
        this.storeCode = this.getVal('store_code') ? this.getVal('store_code') : this.$route.query.store_code;
        this.shareId = this.getVal('shareId') ? this.getVal('shareId') : this.$route.query.shareId;
        const share = this.getVal('share');
        this.xjjOpenId = this.$route.query.xjj_openId;
        // 链接是否带有 xjjOpenId ？ 直接进入start ： 授权
        if (this.xjjOpenId !== "" && typeof this.xjjOpenId !== 'undefined' && this.xjjOpenId !== null) {
          this.start();
        } else {
          authorize(this.activityId, this.openId, this.defaultFrom, this.storeCode, this.friendOpenId, share);
        }
      },
      start(){ // 模板执行入口方法
        getConfig(res => {
          this.config = res;
          this.music = this.config.music;
          // 组合模板图片地址进行预加载
          for (let item in  this.config.images) {
            if (item === 'prize_img_box') {
              for (let p of this.config.images[item]) {
                this.imageArr.push({
                  id: p.item_id,
                  key: 'prize_img',
                  val: p.prize_img
                });
              }
            } else {
              this.imageArr.push({
                id: null,
                key: item,
                val: this.config.images[item]
              });
            }
          }
          // 图片加载完成后进行赋值处理
          this.loadImages((back) => {
            this.images = this.config.images;
            this.setConfig();
            this.wxShare();
          });
        });
      },
      loadImages(callback){        // 加载图片
        const self = this;
        let oImage = new Image();
        oImage.src = this.imageArr[this.iCur].val;
        oImage.onload = function () {
          if (self.imageArr[self.iCur].key === 'share_image') {
            self.shareImage = oImage;
          }
          self.iCur++;
          if (self.iCur < self.imageArr.length) {
            self.loadImages(callback);
          } else {
            callback(1);
          }
        };
      },
      setConfig(){
        const config = JSON.stringify(this.config);
        sessionStorage.removeItem('config');
        sessionStorage.setItem('config', encodeURI(config));
        const itemId = typeof this.shareId === 'undefined' ? -1 : this.shareId;
        const friendOpenId = typeof this.friendOpenId == 'undefined' ? this.openId : this.friendOpenId;
        if (friendOpenId !== this.openId) {
          //砍价对象ID ，当前用户ID ，好友ID
          getDetails(itemId, this.openId, friendOpenId, this.config.host, res => {
            if (res.return_code == 200) {
              this.bargain = res;
              let detailsStr = {
                item_id: itemId,
                originalPrices: res.originalPrices,
                targetPrices: res.targetPrices,
                cutPrices: res.cutPrices,
                limitPrices: res.limitPrices,
                status: res.status,
                helperList: res.helperList,
              };
              detailsStr = JSON.stringify(detailsStr);
              sessionStorage.removeItem('friendDetails');
              sessionStorage.setItem('friendDetails', encodeURI(detailsStr));
              this.show = 'friendBargain';
              this.inLoading = false;
            }
          });
        } else {
          this.show = 'list';
        }
        this.inLoading = false;
      },
      getVal(item) {
        const svalue = location.search.match(new RegExp("[\?\&]" + item + "=([^\&]*)(\&?)", "i"));
        return svalue ? svalue[1] : svalue;
      },
      showSilkBag(){        // 打开锦囊
        if (!this.inDraw) {
          this.hasShowSilkBag = true;
        }
      },
      hideSilkBag(){    //关闭锦囊
        this.hasShowSilkBag = false;
      },
      playMusic(){        //播放暂停音乐
        this.inPlay = !this.inPlay;
        const music = document.getElementById('audio');
        if (this.inPlay) {
          music.play();
        } else {
          music.pause();
        }
      },

      toBargain(back){ //确认砍价对象
        const self = this;
        let detailsStr = {};
        this.loading = true;
        //砍价对象ID ，当前用户ID ，好友ID
        getDetails(back, this.openId, '', this.config.host, res => {
          if (res.return_code == 200) {
            detailsStr = {
              item_id: back,
              originalPrices: res.originalPrices,
              targetPrices: res.targetPrices,
              cutPrices: res.cutPrices,
              limitPrices: res.limitPrices,
              status: res.status,
              helperList: res.helperList,
            };
            self.bargain = detailsStr;
            detailsStr = JSON.stringify(detailsStr);
            sessionStorage.removeItem('details');
            sessionStorage.setItem('details', encodeURI(detailsStr));
            self.show = 'bargain';
            self.loading = false;
          } else {
            alert(res.return_msg);
            self.loading = false;
          }
        });

      },
      tryAgain(back){ //再来一次
        this.show = 'list';
      },
      friendTty(back){ //分享页面--> 我也试试
        sessionStorage.removeItem('friendOpenId');
        this.friendOpenId = undefined;
        this.shareId = undefined;
        this.setConfig();
      },
      wxShare(){
        getWXConfig(res => {
          if (res.return_code == 200) {
            this.wxConfig = {
              appId: res.appId, // 必填，公众号的唯一标识
              timestamp: res.timestamp, // 必填，生成签名的时间戳
              nonceStr: res.nonceStr, // 必填，生成签名的随机串
              signature: res.signature,// 必填，签名，见附录1
            }
          }
          this.setWXConfig();
        });
      },
      setWXConfig(){
        const self = this;
        const title = '好友砍价';
        const imgUrl = self.shareImage.src;
        let link = '';
        let desc = '';

        if (this.show === 'bargain') {
          link = window.location.origin + '/?friendOpenId=' + self.openId +
            '&itemId=' + self.bargain.item_id +
            '&activity_id=' + self.activityId +
            '&store_code=' + self.storeCode +
            '&defaultFrom=' + self.defaultFrom;
          desc = 'Felix邀请你来帮忙！';
        } else {
          link = window.location.origin + '/?share=true' +
            '&activity_id=' + self.activityId +
            '&store_code=' + self.storeCode +
            '&defaultFrom=' + self.defaultFrom;
          desc = '好友砍价，拼友情。';
        }

        wx.config({
          debug: false, // 开启调试模式,调用的所有api的返回值会在客户端打印出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
          appId: this.wxConfig.appId, // 必填，公众号的唯一标识
          timestamp: this.wxConfig.timestamp, // 必填，生成签名的时间戳
          nonceStr: this.wxConfig.nonceStr, // 必填，生成签名的随机串
          signature: this.wxConfig.signature,// 必填，签名，见附录1
          jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        });
        wx.ready(function () {
          self.inReady = false;
          wx.onMenuShareTimeline({
            title: title, // 分享标题
            link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
            imgUrl: imgUrl,
            success: function () {
            },
            cancel: function () {
            }
          });
          wx.onMenuShareAppMessage({
            title: title, // 分享标题
            desc: desc, // 分享描述
            link: link,
            imgUrl: imgUrl, // 分享图标
            success: function () {
            },
            cancel: function () {
            }
          });
        });
      },
    }
  };
</script>
<style scoped lang='less'>
  #template {
    overflow: hidden;
    position: relative;
    width: 100%;
    height: 100%;
    background: #fff;
    img {
      width: 100%;
      height: 100%;
    }
    /*加载动画*/
    .loading {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 99;
      background: #fff;
      width: 100%;
      height: 100%;
      img {
        position: absolute;
        top: 50%;
        left: 50%;
        margin-left: -2.5rem;
        margin-top: -2.5rem;
        width: 5rem;
        height: 5rem;
      }
    }
    /*背景图片*/
    .bg-image {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
    }
    /*音乐组件*/
    .music-image {
      position: fixed;
      top: 1.4rem;
      left: 1rem;
      z-index: 2;
      width: 2.5rem;
      height: 2.5rem;
      border-radius: 50%;
      background-size: cover;
    }
    .music-active {
      animation: active 1s linear infinite;
      @keyframes active {
        0% {
          transform: rotate(0deg);
        }
        100% {
          transform: rotate(360deg);
        }
      }
    }

    /*锦囊*/
    .silk-bag-icon {
      position: fixed;
      top: .5rem;
      right: .5rem;
      z-index: 2;
      width: 3rem;
      height: 3rem;
      border-radius: 50%;
      background-size: cover;
    }
    .bargain {
      position: relative;
      width: 100%;
      height: 100%;
    }

  }

</style>
