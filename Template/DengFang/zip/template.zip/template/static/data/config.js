(function (win) {
  win.config = {
    images: {
      // //背景图
      bg_image: 'static/data/images/bg.png',
      // 点击按钮图
      button_image: 'static/data/images/button.png',
    },
    tooltips: {
      hello: 'Hello Word'
    }
  }
})(window);






