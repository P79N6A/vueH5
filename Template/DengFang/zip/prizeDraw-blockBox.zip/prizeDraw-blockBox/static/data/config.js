(function (win) {
  win.config = {
    images: {
      //背景图
      bg_image: './static/data/images/bg.png',
      //音乐标签
      music_image: './static/data/images/music.png',
      //锦囊标签
      silk_bag_image: './static/data/images/silk-bag.png',
      //锦囊--活动说明图
      illustrate_image: './static/data/images/illustrate.png',
      //奖品图片
      first_prize: './static/data/images/first-prize.png',
      second_prize: './static/data/images/second-prize.png',
      third_prize: './static/data/images/third-prize.png',
      no_prize: './static/data/images/no-prize.png',
      prize_draw: './static/data/images/prize-draw.png'
    },
    //提示信息
    tooltips: {
      prize_draw_number: '您今天还有{n}次抽奖机会'
    },
    //音乐地址
    music: './static/data/test.mp3',
  }
})(window);






