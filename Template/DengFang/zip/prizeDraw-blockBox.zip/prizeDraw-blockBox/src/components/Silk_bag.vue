<template>
  <section id="silk-bag">
    <div class="mask"></div>
    <div class="silk-bag-cnt">
      <div class="silk-bag-close" @click="closeSilkBag"></div>
      <section class="silk-bag-header">
        <div class="silk-bag-tab" v-bind:class="isActive?'silk-bag-tab-active':''" @click="isActive = true">
          <span>活动说明</span>
        </div>
        <div class="silk-bag-tab" v-bind:class="isActive?'':'silk-bag-tab-active'" @click="isActive = false">
          <span>我的奖品</span>
        </div>
      </section>
      <section class="silk-bag-content">
        <div class="illustrate" v-if="isActive">
          <img :src="images.illustrate_image" alt="">
        </div>
        <div class="record" id="record" v-if="!isActive">
          <scroller class="record-list">
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
            <p>测试中奖记录</p>
          </scroller>
          <div class="concern-us" @click="showConcern_us= true">
            关注我们
          </div>
        </div>
      </section>
    </div>
    <Concern_us v-if="showConcern_us" v-on:child-say="closeConcernUs"></Concern_us>
  </section>
</template>
<script>
  import Concern_us from './Concern_us.vue';
  export default {
    components: {Concern_us},
    data() {
      return {
        images: {},
        isActive: true,
        showConcern_us: false,
        hasAddEvent: false
      }
    },
    created(){
      this.images = config.images;
    },
    methods: {
      closeSilkBag(){
        this.$emit('child-say', false);
      },
      closeConcernUs(){
        this.showConcern_us = false;
      }
    }
  }
</script>
<style lang="less" scoped>
  #silk-bag {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
    width: 100%;
    height: 100%;
    img {
      width: 100%;
      height: 100%;
    }
    .mask {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 101;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, .8);
    }
    .silk-bag-cnt {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 102;
      padding: 1rem 0;
      box-sizing: border-box;
      width: 100%;
      height: 100%;
      color: #fff;
      .silk-bag-close {
        position: absolute;
        right: 1rem;
        top: 1rem;
        width: 2.5rem;
        height: 2.5rem;
        background: url("../assets/close.png") no-repeat;
        background-size: cover;
      }
      .silk-bag-header {
        height: 2.8rem;
        font-size: 0;
        border-bottom: 1px solid #fff;
        .silk-bag-tab {
          display: inline-block;
          position: relative;
          width: 40%;
          height: 2.8rem;
          font-size: .8rem;
          line-height: 2.8rem;
          text-align: center;
        }
        .silk-bag-tab-active:before {
          content: '';
          display: block;
          position: absolute;
          bottom: 0;
          left: 50%;
          margin-left: -2.5rem;
          width: 5rem;
          height: 2px;
          background: #fff;
        }
        .silk-bag-tab-active:after {
          content: '';
          display: block;
          position: absolute;
          bottom: 0;
          left: 50%;
          margin-left: -8px;
          width: 0;
          height: 0;
          border-left: 8px solid transparent;
          border-bottom: 8px solid #fff;
          border-top: 8px solid transparent;
          border-right: 8px solid transparent;
        }
      }
      .silk-bag-content {
        height: 100%;
        .record {
          overflow: hidden;
          position: relative;
          text-align: center;
          height: 100%;
          .record-list {
            overflow-y: scroll;
            -webkit-overflow-scrolling: touch;
            padding: .5rem 1rem;
            box-sizing: border-box;
            max-height: 100%;
            text-align: left;
            font-size: .8rem;
            border-bottom: 7.5rem solid transparent;
            p {
              margin-bottom: .3rem;
            }
          }
          .concern-us {
            position: absolute;
            left: 50%;
            bottom: 4.5rem;
            margin-left: -5.75rem;
            width: 11.5rem;
            height: 2.5rem;
            font-size: .8rem;
            line-height: 2.5rem;
            background: #64a737;
            border-radius: 5px;
          }
        }
      }
    }
  }
</style>
