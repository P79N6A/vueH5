<template>
  <section id="prize-result-result">
    <div class="mask"></div>
    <div class="prize-result-cnt">
      <div class="prize-result-content">
        <p class="prize-result-title">恭喜您!</p>
        <div class="prize-result-describe">
          <p>您获得了</p>
          <div class="prize-result-details">
            <div class="coupons-image">
              <img src="../assets/prize.png" alt="">
            </div>
            <div class="coupons-title">
              <p>真的有料</p>
              <p>水果礼券</p>
            </div>
          </div>
          <div class="view-immediately" @click="">立即查看</div>
        </div>
      </div>
    </div>
    <div class="again" @click="again">再来一次</div>
  </section>
</template>
<script>
  export default {
    data() {
      return {}
    },
    methods: {
      again(){
        this.$emit('child-say', true);
      }
    }
  }
</script>
<style lang="less" scoped>
  #prize-result-result {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
    width: 100%;
    height: 100%;
    img {
      width: 100%;
      height: 100%;
    }
    .mask {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 101;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, .8);
    }
    .prize-result-cnt {
      position: fixed;
      bottom: 5.7rem;
      left: 0;
      z-index: 102;
      width: 100%;
      height: 22rem;
      color: #fff;
      background: url("../assets/prize-result-bg.png") no-repeat;
      background-size: cover;
      .prize-result-content {
        position: absolute;
        bottom: 0;
        z-index: 203;
        width: 100%;
        text-align: center;
        .prize-result-title {
          font-size: 1.2rem;
          margin-bottom: 1.4rem;
        }
        .prize-result-describe {
          position: relative;
          margin: 0 auto;
          width: 12rem;
          height: 13.25rem;
          color: #e8000d;
          font-size: .8rem;
          font-weight: 700;
          .prize-result-details {
            margin: 1rem 0;
            padding: .5rem 0;
            box-sizing: border-box;
            height: 7rem;
            font-size: 0;
            background: #cb2925;
            border: .5rem solid #e8000d;
            .coupons-image {
              display: inline-block;
              width: 45%;
              height: 100%;
              img {
                width: 4rem;
                height: 4rem;
                vertical-align: middle;
              }
            }
            .coupons-title {
              display: inline-block;
              vertical-align: middle;
              padding: 1.5rem 0;
              box-sizing: border-box;
              width: 54%;
              height: 100%;
              font-size: .8rem;
              color: #fff;
              border-left: 1px solid #fff;
            }
          }
          .view-immediately {
            height: 2rem;
            text-align: center;
            color: #fff;
            font-size: .8rem;
            line-height: 2rem;
            background: #e8000d;
            border-radius: 3px;
          }
        }
      }
    }
    .again {
      position: absolute;
      left: 50%;
      bottom: 2.75rem;
      z-index: 102;
      margin-left: -5.75rem;
      width: 11.5rem;
      height: 2.5rem;
      text-align: center;
      color: #fff;
      font-size: .8rem;
      line-height: 2.5rem;
      background: #64a737;
      border-radius: 5px;
    }
  }
</style>
