// 需要jquery支持

const getcoupon = (openid, activity_id, third_party_openid, third_party_name, subscribe) => {
    var return_type = {};
    var getCoupon = {
        "openid": openid,
        "activity_id": activity_id,
        "third_party_openid": third_party_openid,
        "third_party_name": third_party_name
    };
    $.ajax({
        type: "POST",
        url: "http://ab.aikaka.com.cn/Acmp/AcmpApi/shakeFor/drawCoupon",
        data: getCoupon,
        dataType: "json",
        async: false,
        success: function(data) {
            if (data.return_code != 200) {
                return_type.return_code = "500";
                return_type.return_msg = data.return_msg;
            } else {
                return_type.return_code = "200";
                return_type.return_msg = "";
                if (subscribe == 1) {
                    // 获取需要的字段例如coupon_id;
                    return_type.coupon_id = data.data.coupon_id;
                } else {
                    var getCoupon_qr = {};
                    getCoupon_qr.coupon_code = data.data.coupon_code
                    $.ajax({
                        type: "GET",
                        url: "http://ab.aikaka.com.cn/Acmp/AcmpApi/shakeFor/guideQr",
                        data: getCoupon_qr,
                        dataType: "json",
                        async: false,
                        success: function(data) {
                            if (data.return_code != 200) {
                                //备用的引导关注页二维码
                                return_type.subscribe_qr_url = "http://ab.aikaka.com.cn/PublicService/Util/qrcode.php?code=" + encodeURIComponent('http://t.cn/RcBraHp');
                                //备用的引导关注页url
                                return_type.subscribe_url = 'http://t.cn/RcBraHp';
                            } else {
                                //接口正常返回的引导关注页二维码
                                return_type.subscribe_qr_url = "http://ab.aikaka.com.cn/PublicService/Util/qrcode.php?code=" +
                                    encodeURIComponent(data.data.qr_code_url);
                                //接口正常返回的引导关注页url
                                return_type.subscribe_url = data.data.qr_code_url;
                            }
                        },
                        error: function(data) {
                            //备用的引导关注页二维码
                            return_type.subscribe_qr_url = "http://ab.aikaka.com.cn/PublicService/Util/qrcode.php?code=" + encodeURIComponent('http://t.cn/RcBraHp');
                            //备用的引导关注页url
                            return_type.subscribe_url = 'http://t.cn/RcBraHp';
                        }
                    });
                }
            }
        },
        error: function(data) {
            return_type.return_code = "500";
            return_type.return_msg = "网络异常";
        }
    });
    return return_type;

    // 成功的返回
    // return_type = {
    //     return_code: "200",
    //     return_msg: "", 
    //     coupon_id: "",//卡券的id
    //     subscribe_qr_url: "", //引导关注的二维码已经转成图片直接在img元素的src属性引用
    //     subscribe_url: "" //如需页面跳转引导关注的地址
    // }

    // 失败的返回
    // return_type = {
    //     return_code: "500",
    //     return_msg: "" //异常信息
    // }

};
export { getcoupon }
