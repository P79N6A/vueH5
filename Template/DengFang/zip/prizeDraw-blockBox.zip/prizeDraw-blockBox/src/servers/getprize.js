const getprize = () => {
  const prize = Math.round(Math.random() * 3);
  // 成功的返回
  return {
    return_code: "200",
    return_msg: "",
    prize: prize
  };
};
export {getprize};
