const getsequence = () => {
  // 成功的返回
  return {
    return_code: "200",
    return_msg: "",
    sequence: [1, 2, 3, 3, 0, 2, 0, 3]
  }
};
export {getsequence};
