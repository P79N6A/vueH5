<template>
  <section id="template">
    <div class="loading" v-if="inLoading">
      <img src="../assets/loading-bars.svg">
    </div>
    <img class="bg-image" :src="images.bg_image" alt="">
    <div class="music-image" :class='inPlay?"music-active":""' :style='{backgroundImage:"url("+images.music_image+")"}'
         @click="playMusic"></div>
    <audio loop="loop" id="audio" :src="music"></audio>
    <div class="silk-bag-image" :style='{backgroundImage:"url("+images.silk_bag_image+")"}' @click="clickSilkBag"></div>
    <!--模板组件内修改-->
    <div class="prize-area">
      <div class="prize-area-bg-up" v-if="prizeAreaBgActive"></div>
      <div class="prize-area-bg" v-if="!prizeAreaBgActive"></div>
      <div class="prize-arr">
        <div class="prize-parent" v-for="val in sequence" :key="val">
          <div class="first-prize" :style='{backgroundImage:"url("+images.first_prize+")"}' v-if="val === 1"></div>
          <div class="second-prize" :style='{backgroundImage:"url("+images.second_prize+")"}' v-if="val === 2"></div>
          <div class="third-prize" :style='{backgroundImage:"url("+images.third_prize+")"}' v-if="val === 3"></div>
          <div class="no-prize" :style='{backgroundImage:"url("+images.no_prize+")"}' v-if="val === 0"></div>
          <div class="prize-draw" :style='{backgroundImage:"url("+images.prize_draw+")"}' v-if="val === -1"
               @click="prizeDraw"></div>
        </div>
        <div class="prize-mask" v-if="inPrizeDraw"></div>
      </div>
    </div>
    <div class="prize-draw-number-text" v-html="prizeDrawNumberText"></div>
    <!--锦囊组件-->
    <Silk_bag v-if="showSilkBag" v-on:child-say="closeSilkBag"></Silk_bag>
    <!--开奖结果组件-->
    <Prize_result v-if="showPrizeResult" v-on:child-say="again"></Prize_result>
  </section>
</template>
<script>
  import Silk_bag from "../components/Silk_bag.vue";
  import Prize_result from "../components/Prize_result.vue";
  import {getsequence} from "../servers/getsequence";
  import {getprize} from "../servers/getprize";
  export default {
    components: {
      Silk_bag,
      Prize_result
    },
    data() {
      return {
        // ---------------------共用属性-----------------------
        xjj_openId: '',
        inLoading: true, //加载状态
        images: {}, //图片集--用作图片展示
        imageArr: {},//图片集--用作判断图片加载状态
        music: '', //音乐地址
        inPlay: false, //是否在播放音乐
        oImage: new Image(), //图片对象，用作加载图片
        iCur: 0, //图片加载的序号
        showSilkBag: false, //锦囊
        showPrizeResult: false, //抽奖结果
        inPrizeDraw: false, //是否处于抽奖状态
        hasGetPrize: false, // 当前轮数是否已抽奖
        prizeDrawNumberText: '', //抽奖次数提示语
        prizeDrawNumber: 2, //默认抽奖次数
        // ---------------------私有属性-----------------------
        prizeAreaBgActive: false, //奖盘背景动画状态
        sequence: [],//奖品序列
        speed: 100, //初始转到速度
        timeNumber: 0, //转动的总时长
        showArr: [0, 1, 2, 5, 8, 7, 6, 3], //奖盘排列序号
        animationIndex: 0, //当前展示动画的序号
        timer: 0, //动画声明
        prize: -1 //默认奖品
      }
    },
    created(){
      this.music = config.music;
      document.querySelector("body").addEventListener("touchmove", function (e) {
        e.preventDefault();
      });
      this.xjj_openId = localStorage.getItem("xjj_openId");
      if (this.xjj_openId !== "" && typeof this.xjj_openId !== 'undefined' && this.xjj_openId !== null) {
        this.start();
      } else {
        /*    this.pageOrization((xjj_openId) => {
         localStorage.setItem("xjj_openId", xjj_openId);
         this.start();
         });*/
        this.start();
      }
    },
    methods: {
      start(){
        // 模板执行入口方法
        this.imageArr = config.images;
        const prizeDrawNumberText = config.tooltips.prize_draw_number;
        this.prizeDrawNumberText = prizeDrawNumberText.replace("{n}", '<span style="color: #fff"> ' + this.prizeDrawNumber + ' </span>');
        // 图片加载完成后进行赋值处理
        this.imgLoad((back) => {
          this.images = {
            "bg_image": config.images.bg_image,
            "music_image": config.images.music_image,
            "silk_bag_image": config.images.silk_bag_image,
            "first_prize": config.images.first_prize,
            "second_prize": config.images.second_prize,
            "third_prize": config.images.third_prize,
            "no_prize": config.images.no_prize,
            "prize_draw": config.images.prize_draw,
          };
          this.inLoading = false;
          // 获取奖项序列，并插入开始抽奖按钮
          const json = getsequence();
          const oldSequence = json.sequence;
          oldSequence.splice(4, 0, -1);
          this.sequence = oldSequence;
          this.prizeAreaBgAnimation();
        });
      },
      imgLoad(callback){
        // 加载图片
        const self = this;
        const arr = Object.keys(this.imageArr);
        this.oImage.src = this.imageArr[arr[this.iCur]];
        this.oImage.onload = function () {
          self.iCur++;
          if (self.iCur < arr.length) {
            self.imgLoad(callback);
          } else {
            callback(1);
          }
        };
      },
      prizeAreaBgAnimation(){
        //改变奖盘背景状态
        this.prizeAreaBgActive = !this.prizeAreaBgActive;
        setTimeout(this.prizeAreaBgAnimation, 250);
      },
      closeSilkBag(){
        //关闭锦囊
        this.showSilkBag = false;
      },
      playMusic(){
        //播放暂停音乐
        this.inPlay = !this.inPlay;
        const music = document.getElementById("audio");
        if (this.inPlay) {
          music.play();
        } else {
          music.pause();
        }
      },
      prizeDraw(){
        //抽奖
        if (this.inPrizeDraw) {
          return false;
        }
        if (this.prizeDrawNumber <= 0) {
          alert("您今天的抽奖次数用完啦! ");
          return false;
        }
        this.prizeDrawNumber--;
        const prizeDrawNumberText = config.tooltips.prize_draw_number;
        this.prizeDrawNumberText = prizeDrawNumberText.replace("{n}", '<span style="color: #fff"> ' + this.prizeDrawNumber + ' </span>');
        this.inPrizeDraw = true;
        this.prizeAnimation();
      },
      prizeAnimation(){
        //抽奖动画
        const self = this;
        if (this.animationIndex >= 8) {
          this.animationIndex = 0;
          $(".prize-parent").removeClass("prize-active");
        }
        $(".prize-parent").eq(this.showArr[this.animationIndex]).addClass("prize-active");
        $(".prize-parent").eq(this.showArr[this.animationIndex - 1]).removeClass("prize-active");
        if (this.timeNumber > 2000 && this.timeNumber <= 3500) {
          this.speed += 50;
          this.onGetprize();
        }
        //if (this.timeNumber > 3500 && this.prize !== -1 && this.prize === this.sequence[this.animationIndex]) {
        if (this.timeNumber > 3500 && this.prize !== -1 && this.prize === this.animationIndex) {
          clearTimeout(this.timer);
          this.timer = 0;
          setTimeout(function () {
            self.showPrizeResult = true;
          }, 500);
          return false;
        }
        this.animationIndex++;
        this.timeNumber += this.speed;
        this.timer = setTimeout(this.prizeAnimation, this.speed);
      },
      onGetprize(){
        // 获取奖项
        if (!this.hasGetPrize) {
          this.hasGetPrize = true;
          const prizeBack = getprize();
          this.prize = prizeBack.prize;
        }
      },
      again(callback){
        //再来一次
        this.showPrizeResult = false;
        this.animationIndex = 0;
        this.speed = 100;
        this.timeNumber = 0;
        this.inPrizeDraw = false;
        this.prize = -1;
        this.hasGetPrize = false;
        $(".prize-parent").removeClass("prize-active");
      },
      clickSilkBag(){
        // 打开锦囊
        if (!this.inPrizeDraw) {
          this.showSilkBag = true;
        }
      }
    }
  };
</script>
<style scoped lang="less">
  @import "../assets/index";
</style>
