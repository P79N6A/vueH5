//请用异步请求
//friendOpenid: 好友的openid，通过分享链接上带入
const getFriendDetails = (openid, friendOpenid, xx_id, xxx_id, callback) => {
  // 成功的返回
  callback({
    return_code: "200",
    return_msg: "",
    item_id: "2", //卡券的item_id，
    originalPrices: '100.0', //原价
    targetPrices: '0.0', //目标价格
    cutPrices: '90.0', //已经砍掉的价格
    helperList: [   //当前好友砍价信息
      {
        headImage: '',   //头像地址
        name: 'Felix',   // 昵称
        dateTime: '2017-07-21 18:30:25',  //砍价时间
        prices: '30.0'  //砍价金额
      }
    ],
  });
  // 失败的返回
  // callback({
  //     return_code: "500",
  //     return_msg: "" //异常信息
  // });
};
export {getFriendDetails}
