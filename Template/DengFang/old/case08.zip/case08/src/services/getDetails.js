/**
 * 请用异步请求
 *
 * 卡券id（砍价对象id）
 * 1、当用户进入活动时调用该接口，不存在卡券id，即卡券id为-1；
 * 2、当用户选定砍价对象时调用该接口，卡券id为对应的砍价对象的id。
 *
 * bargain:砍价对象数组
 * 1、当用户传入砍价对象ID（itemId）时，只需传回当前id对应的砍价对象信息即可，用于确认砍价对象，
 * 2、当好友传入砍价对象ID（itemId）时，只需传回当前id对应的砍价对象信息即可，用于好友砍价，
 * 3、当未传入砍价对象ID（itemId）或砍价对象ID（itemId）为-1时，需要传回当前用户所有的砍价对象信息，用于展示砍价列表或展示正在砍价对象的详情。
 */
const getDetails = (itemId, openid, friendOpenid, xx_id, xxx_id, callback) => {
  callback({
    return_code: "200",
    return_msg: "",
    bargain: [
      /*{
       item_id: "3", //卡券的item_id，
       originalPrices: '10.0', //原价
       targetPrices: '0.0', //目标价格
       cutPrices: '10.0', //已经砍掉的价格
       status: 'undo',//砍价状态 可以砍价/砍价完成但未兑换卡券/砍价完成且已兑换卡券
       helperList: [  //帮助砍价的好友列表
       {
       headImage: '',   //头像地址
       name: 'Felix',   // 昵称
       dateTime: '2017-07-21 18:40:25',  //砍价时间
       prices: '10.0'  //砍价金额
       }
       ],
       },
       {
       item_id: "2", //卡券的item_id，
       originalPrices: '100.0', //原价
       targetPrices: '100.0', //目标价格
       cutPrices: '100.0', //已经砍掉的价格
       status: 'undo',//砍价状态 可以砍价/砍价完成但未兑换卡券/砍价完成且已兑换卡券
       helperList: [   //帮助砍价的好友列表
       {
       headImage: '',   //头像地址
       name: 'Felix',   // 昵称
       dateTime: '2017-07-21 18:40:25',  //砍价时间
       prices: '30.0'  //砍价金额
       },
       {
       headImage: '',   //头像地址
       name: 'undo',   // 昵称
       dateTime: '2017-07-22 18:40:25',  //砍价时间
       prices: '30.0'  //砍价金额
       }
       ],
       }*/
    ],
  });


  // 失败的返回
  // callback({
  //     return_code: "500",
  //     return_msg: "" //异常信息
  // })

};
export {getDetails}
